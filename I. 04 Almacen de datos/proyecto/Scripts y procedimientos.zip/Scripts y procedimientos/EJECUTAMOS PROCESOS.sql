EXECUTE ETL_STG_CATEGORIAS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_CUSTOMERS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_EMPLOYEES;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_ORDERDETAILS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_ORDERS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_PRODUCTS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_SHIPPERS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_SUPPLIERS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_DIM_CLIENTES;
EXECUTE ETL_DIM_CLIENTES;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_GEOGRAFIA;
EXECUTE ETL_STG_DIM_GEOGRAFIA;
EXECUTE ETL_DIM_GEOGRAFIA;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_PRODUCTS;
EXECUTE ETL_STG_DIM_PRODUCTOS;
EXECUTE ETL_DIM_PRODUCTOS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_EMPLOYEES;
EXECUTE ETL_STG_DIM_EMPLEADOS;
EXECUTE ETL_DIM_EMPLEADOS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_DIM_TIEMPO;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_SHIPPERS;
EXECUTE ETL_STG_DIM_SHIPPERS;
EXECUTE ETL_DIM_SHIPPERS;
select * from log_de_procesos order by fec_fin DESC;

EXECUTE ETL_STG_FACT_PEDIDOS;
EXECUTE ETL_FACT_PEDIDOS;
select * from log_de_procesos order by fec_fin DESC;